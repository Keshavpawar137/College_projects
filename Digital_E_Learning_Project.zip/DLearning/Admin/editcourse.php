<link rel="stylesheet" href="./adminInclude/addcourse.css">
<?php 
define('TITLE', 'Courses');
define('PAGE', 'courses');
include('../dbConnection.php');

?>

<?php
if(!isset($_SESSION)){ 
    session_start(); 
  }

if(isset($_SESSION['is_admin_login'])){
    $adminEmail = $_SESSION['adminLogEmail'];
   } else {
    echo "<script> location.href='../index.php'; </script>";
   }


if(isset($_REQUEST['view'])){

  $sql= "SELECT * FROM  course WHERE course_id={$_REQUEST['id']}";
  $result=$conn->query($sql);
  $row=$result->fetch_assoc();
}

?>

<div class="container"><br>
    <h2>Edit Course</h2>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <!-- Your form fields -->
        <label for="course_id">Course id:</label><br>
       <input type="text" id="course_id" name="course_id" value="<?php if(isset($row['course_id'])) {echo $row['course_id'];} ?>" readonly><br>
        <label for="course_name">Course Name:</label><br>
       <input type="text" id="course_name" name="course_name" value="<?php if(isset($row['course_name'])) {echo $row['course_name'];} ?>" ><br>
        <label for="course_description">Course Description:</label><br>
        <textarea id="course_desc" name="course_desc" rows="4" ><?php if(isset($row['course_desc'])) {echo $row['course_desc'];} ?></textarea><br>
        <label for="course_author">Author Name:</label><br>
        <input type="text" id="course_author" name="course_author" value="<?php if(isset($row['course_author'])) {echo $row['course_author'];} ?>"><br>
        <label for="course_duration">Course Duration:</label><br>
        <input type="text" id="course_duration" name="course_duration" value="<?php if(isset($row['course_duration'])) {echo $row['course_duration'];} ?>"><br>
        <label for="course_price">Selling Price:</label><br>
        <input type="number" id="course_price" name="course_price" value="<?php if(isset($row['course_price'])) {echo $row['course_price'];} ?>"><br>
        <label for="selling_price">Original Price:</label><br>
        <input type="number" id="selling_price" name="selling_price" value="<?php if(isset($row['course_original_price'])) {echo $row['course_original_price'];} ?>"><br>
        <label for="course_image">Course Image:</label><br>
        
        <img  src="<?php if(isset($row['course_img'])) {echo $row['course_img'];} ?> " style="width:280px; height:150px;">
        <input type="file" id="course_image" name="course_image" accept="image/*" value=""><br><br>
        <button type="submit" class="btn" id="requpdate" name="requpdate" style="background-color: green; color: white;">Update</button>

        <!-- <input type="submit" value="Update"> -->
        <button type="button" onclick="closeForm()">Close</button>

    </form>
</div>

<script>
    function closeForm() {
        window.location.href = "courses.php";
    }

    function showAlert(message) {
        alert(message);
    }
</script>
<?php
// Update
if(isset($_REQUEST['requpdate'])){
    // Checking for Empty Fields
    if(($_REQUEST['course_id'] == "") || ($_REQUEST['course_name'] == "") || ($_REQUEST['course_desc'] == "") || ($_REQUEST['course_author'] == "") || ($_REQUEST['course_duration'] == "")  || ($_REQUEST['course_price'] == "") ||($_REQUEST['selling_price'] == "")|| ($_REQUEST['course_duration'] == "")){
     // msg displayed if required field missing
     $msg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Fill All Fileds </div>';
    } else {
      // Assigning User Values to Variable
      $cid = $_REQUEST['course_id'];
      $cname = $_REQUEST['course_name'];
      $cdesc = $_REQUEST['course_desc'];
      $cauthor = $_REQUEST['course_author'];
      $cduration = $_REQUEST['course_duration'];
      $cprice = $_REQUEST['course_price'];
      $cour_org_price = $_REQUEST['selling_price'];
      $cimg = '../image/courseimg/'. $_FILES['course_image']['name'];
      
     $sql = "UPDATE course SET course_id = '$cid', course_name = '$cname', course_desc = '$cdesc', course_author='$cauthor', course_duration='$cduration', course_price='$cprice',course_original_price='$cour_org_price', course_img='$cimg'WHERE course_id = '$cid'";


      if($conn->query($sql) == TRUE){
       // below msg display on form submit success
       echo '<script>alert("Course update sucessfull");</script>';
      } else {
        echo '<script>alert("Course update Fail");</script>';
       // below msg display on form submit failed
      }
    } 
    }

?>

<?php
include('./adminInclude/footer.php'); 
?>

