<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Lesson</title>
   
    <style>
        /* Your CSS styles */
        .container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .view-products-btn {
            position: fixed;
            top: 20px;
            left: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add Lesson</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <label for="lesson_name">Lesson Name:</label><br>
        <input type="text" id="lesson_name" name="lesson_name" required><br>
        <label for="lesson_desc">Lesson Description:</label><br>
        <textarea id="lesson_desc" name="lesson_desc" rows="4" required></textarea><br>
        <label for="lesson_link">Upload Video:</label><br>
        <input type="file" id="lesson_link" name="lesson_link" accept="video/*" required><br>
        <label for="course_id">Course ID:</label><br>
        <input type="text" id="course_id" name="course_id" required><br>
        <label for="course_name">Course Name:</label><br>
        <input type="text" id="course_name" name="course_name" required><br><br>
        <input type="submit" value="Submit">
    </form>
</div>

<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "lms_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch lesson details from the form
    $lesson_name = $_POST['lesson_name'];
    $lesson_desc = $_POST['lesson_desc'];
    $lesson_link = $_FILES['lesson_link']['name']; // Changed to get the file name
    $course_id = $_POST['course_id'];
    $course_name = $_POST['course_name'];
    $target_dir = "../lessonvid/";
    $target_file = $target_dir . basename($_FILES["lesson_link"]["name"]);
    move_uploaded_file($_FILES["lesson_link"]["tmp_name"], $target_file);
    
     
    // Insert lesson into the database
    $sql = "INSERT INTO lesson (lesson_name, lesson_desc, lesson_link, course_id, course_name) VALUES ('$lesson_name','$lesson_desc',' $target_file','$course_id','$course_name')";

    if ($conn->query($sql) === TRUE) {
        // Upload lesson video to server
       
        echo "<script>alert('Lesson added successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }

    $conn->close();
}
?>
<button class="view-products-btn" id="viewProductsBtn">View lession</button>

<script>
    document.getElementById('viewProductsBtn').addEventListener('click', function() {
        window.location.href = '../index.php';
    });
</script>


</body>
</html>
