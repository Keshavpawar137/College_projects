<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>
    <link rel="stylesheet" href="./adminInclude/addcourse.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">

</head>
<?php
if(!isset($_SESSION)){ 
    session_start(); 
  }
define('TITLE', 'Courses');
define('PAGE', 'courses');
//include('./adminInclude/header.php'); 
include('../dbConnection.php');
if(isset($_SESSION['is_admin_login'])){
    $adminEmail = $_SESSION['adminLogEmail'];
   } else {
    echo "<script> location.href='../index.php'; </script>";
   }
   
?>
<body>
    <div class="navbar">
<nav class="navbar navbar-dark fixed-top p-0 shadow" style="background-color: #f00975; ">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="adminDashboard.php">Online Free learning <small class="text-white">Admin Area</small></a> 
 </nav> 
 </div>

 
<div class="container">
    <h2>Add Course</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <!-- Your form fields -->
        <label for="course_name">Course Name:</label><br>
        <input type="text" id="course_name" name="course_name" required><br>
        <label for="course_description">Course Description:</label><br>
        <textarea id="course_description" name="course_description" rows="4" required></textarea><br>
        <label for="author_name">Author Name:</label><br>
        <input type="text" id="author_name" name="author_name" required><br>
        <label for="course_duration">Course Duration:</label><br>
        <input type="text" id="course_duration" name="course_duration" required><br>
        <label for="original_price">Original Price:</label><br>
        <input type="number" id="original_price" name="original_price" required><br>
        <label for="selling_price">Selling Price:</label><br>
        <input type="number" id="selling_price" name="selling_price" required><br>
        <label for="course_image">Course Image:</label><br>
        <input type="file" id="course_image" name="course_image" accept="image/*" required><br><br>
        <input type="submit" value="Submit">
        <button type="button" onclick="closeForm()">Close</button>

    </form>
</div>

<script>
    function closeForm() {
        window.location.href = "courses.php";
    }

    function showAlert(message) {
        alert(message);
    }
</script>


<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "lms_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch course details from the form
    $course_name = $_POST['course_name'];
    $course_description = $_POST['course_description'];
    $author_name = $_POST['author_name'];
    $course_duration = $_POST['course_duration'];
    $original_price = $_POST['original_price'];
    $selling_price = $_POST['selling_price'];
    $course_image = $_FILES['course_image']['name'];
    $target_dir = "../image/courseimg";
    $target_file = $target_dir . basename($_FILES["course_image"]["name"]);

    // Insert course image path into the database
    $sql = "INSERT INTO course (course_name, course_desc, course_author, course_img, course_duration, course_price, course_original_price) VALUES ('$course_name','$course_description','$author_name','$target_file','$course_duration','$original_price','$selling_price')";

    if ($conn->query($sql) === TRUE) {
        // Upload course image to server
        move_uploaded_file($_FILES["course_image"]["tmp_name"], $target_file);
        echo "<script>showAlert('Course added successfully');</script>";
    } else {
        echo "<script>showAlert('Error: " . $conn->error . "');</script>";
    }

    
    $conn->close();
}
?>

</body>
</html>
