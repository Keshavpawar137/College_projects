<?php
if(!isset($_SESSION)){ 
  session_start(); 
}
define('TITLE', 'Add Student');
// include('./adminInclude/header.php'); 
include('../dbConnection.php');

 if(isset($_SESSION['is_admin_login'])){
  $adminEmail = $_SESSION['adminLogEmail'];
 } else {
  echo "<script> location.href='../index.php'; </script>";
 }
 if(isset($_REQUEST['newStuSubmitBtn'])){
  // Checking for Empty Fields
  if(($_REQUEST['stu_name'] == "") || ($_REQUEST['stu_email'] == "") || ($_REQUEST['stu_pass'] == "") || ($_REQUEST['stu_occ'] == "")){
   // msg displayed if required field missing
   $msg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Fill All Fileds </div>';
  } else {
   // Assigning User Values to Variable
   $stu_name = $_REQUEST['stu_name'];
   $stu_email = $_REQUEST['stu_email'];
   $stu_pass = $_REQUEST['stu_pass'];
   $stu_occ = $_REQUEST['stu_occ'];

    $sql = "INSERT INTO student (stu_name, stu_email, stu_pass, stu_occ) VALUES ('$stu_name', '$stu_email', '$stu_pass', '$stu_occ')";
    if($conn->query($sql) == TRUE){
     // below msg display on form submit success
     $msg = '<div class="alert alert-success col-sm-6 ml-5 mt-2" role="alert"> Student Added Successfully </div>';
    } else {
     // below msg display on form submit failed
     $msg = '<div class="alert alert-danger col-sm-6 ml-5 mt-2" role="alert"> Unable to Add Student </div>';
    }
  }
  }

 ?>
 <style>
body {
    font-family: Arial, sans-serif;
}

.container {
    margin-top: 20px;
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
}

.form-container {
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
}

.form-title {
    text-align: center;
}

.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
}

.input-field {
    width: 100%;
    padding: 8px;
}

.form-actions {
    text-align: center;
    margin-top: 15px;
}

.btn {
    padding: 8px 20px;
    cursor: pointer;
    text-decoration: none;
    border: none;
    border-radius: 3px;
}

.btn-danger {
    background-color: #dc3545;
    color: #fff;
}

.btn-secondary {
    background-color: #6c757d;
    color: #fff;
    margin-left: 10px;
}

  

 </style>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to external CSS file -->
</head>
<body>

<div class="container">
    <div class="form-container">
        <h3 class="form-title">Add New Student</h3>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="stu_name">Name</label>
                <input type="text" class="form-control" id="stu_name" name="stu_name">
            </div>
            <div class="form-group">
                <label for="stu_email">Email</label>
                <input type="text" class="form-control" id="stu_email" name="stu_email">
            </div>
            <div class="form-group">
                <label for="stu_pass">Password</label>
                <input type="password" class="form-control" id="stu_pass" name="stu_pass">
            </div>
            <div class="form-group">
                <label for="stu_occ">Occupation</label>
                <input type="text" class="form-control" id="stu_occ" name="stu_occ">
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-danger" id="newStuSubmitBtn" name="newStuSubmitBtn">Submit</button>
                <a href="students.php" class="btn btn-secondary">Close</a>
            </div>
            <?php if(isset($msg)) { echo $msg; } ?>
        </form>
    </div>
</div>

</body>
</html>

<?php
include('./adminInclude/footer.php'); 
?>